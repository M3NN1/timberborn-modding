# Beaver Behavior Breakdown — Design Document

## Vision

Every beaver gets a persistent personality. Traits interact with each other and with nearby beavers, creating emergent colony behavior that's different every playthrough. Humor isn't written — it emerges when systems collide.

## Design Principles

1. **No scripted events** — all outcomes emerge from trait math
2. **Per-colony identity** — separated colonies develop differently because different trait combinations dominate
3. **Systems, not scripts** — the mod defines rules, not outcomes
4. **Visible chaos** — players see WHY things happen (trait panel, event log)
5. **Balanced disruption** — traits affect gameplay meaningfully but don't break it

## System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Game Loop (per tick)                   │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────┐    ┌─────────────────────┐            │
│  │ Trait System  │───▶│ Behavior Modifiers  │            │
│  │ (per beaver)  │    │ (work, move, needs) │            │
│  └──────┬───────┘    └─────────────────────┘            │
│         │                                                │
│         ▼                                                │
│  ┌──────────────────────┐    ┌───────────────────┐      │
│  │ Social Interaction    │───▶│ Event Emitter     │      │
│  │ (radius, influence)   │    │ (pattern detect)  │      │
│  └──────────────────────┘    └────────┬──────────┘      │
│                                        │                 │
│                                        ▼                 │
│                              ┌───────────────────┐       │
│                              │ UI Overlay         │       │
│                              │ (panel + log)      │       │
│                              └───────────────────┘       │
└─────────────────────────────────────────────────────────┘
```

## Trait Interaction Matrix (examples)

| Beaver A | Beaver B | Emergent Result |
|----------|----------|-----------------|
| NaturalLeader | Anarchist | Conflict → both Frustrated → nearby beavers pick sides |
| Gossip | Slacker | Laziness spreads → ProductivityCollapse event |
| Copycat | Hyperactive | Copycat exhausts itself mimicking speed |
| Perfectionist | Procrastinator | Perfectionist gets Frustrated, works even slower |
| Loner | (crowded area) | LonerOverload → Panicked → panic spreads to Paranoid |
| Optimist | Dramatic | Dramatic amplifies Optimist's good vibes → Euphoria cascade |
| 2x NaturalLeader | (same area) | LeadershipChallenge → colony splits allegiance |

## Mood Propagation Rules

- Moods are **transient** (recalculated every 2s), traits are **permanent**
- Influence falls off with distance (linear within radius)
- Mimicry amplifies received influence
- Negative influence (Contrarian, Loner) creates "dead zones"
- Chaotic traits add randomness to mood calculations
- 3+ beavers in same mood = chain reaction event

## Stat Modifier Stacking

All trait modifiers multiply together, then mood modifier applies on top:

```
EffectiveStat = BaseValue × Trait1Mod × Trait2Mod × ... × MoodMod
```

Clamped to prevent game-breaking values (e.g., work speed: 0.2x – 3.0x).

## Save/Load

- Trait assignments persist via `IPersistentEntity`
- Mood is saved but recalculated on next tick anyway
- Event log is NOT saved (ephemeral by design)

## Future Expansion Ideas

- **Trait inheritance** — baby beavers get traits influenced by parents
- **Trait evolution** — long-lived beavers develop new traits
- **Colony reputation** — districts known for specific trait concentrations
- **Trait buildings** — "Therapy Hut" reduces conflict, "Arena" channels it
- **Cross-colony influence** — traders spread traits between districts
