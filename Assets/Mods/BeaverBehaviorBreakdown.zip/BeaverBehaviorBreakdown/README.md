# Beaver Behavior Breakdown

A Timberborn mod that adds persistent personality traits to every beaver, generating emergent chaos through system interactions — not scripted jokes.

## Design Philosophy

- **No fixed events** — everything emerges from traits
- **Traits interact** → unexpected colony behavior for each separated colony
- **Humor comes from systems colliding**, not from text or scripted gags
- Each colony develops its own unique "personality" over time

## Core Systems

| System | Responsibility |
|--------|---------------|
| **Trait System** | Assigns and stores persistent personalities per beaver |
| **Behavior Modifier System** | Alters gameplay stats (work speed, needs, movement) |
| **Social Interaction System** | Beavers affect each other (influence, conflict, mimicry) |
| **Event Emitter System** | Logs and surfaces funny emergent outcomes |
| **UI Overlay System** | Shows traits & moods on beaver selection |

## Architecture

Built on Timberborn's Bindito DI framework:
- `[Context("Game")]` configurators for all systems
- `BaseComponent` classes for per-beaver behavior
- `ComponentSpec` records for Blueprint-driven trait definitions
- `ILoadableSingleton` / `IUpdatableSingleton` for global services
- Decoration system to attach trait components to beaver entities

## Project Structure

```
timberborn-beaver-behavior-breakdown/
├── manifest.json
├── Scripts/
│   ├── Core/                    # Trait definitions, enums, data
│   ├── TraitSystem/             # Assignment, storage, persistence
│   ├── BehaviorModifiers/       # Stat alterations per trait
│   ├── SocialInteraction/       # Influence, conflict, propagation
│   ├── EventEmitter/            # Emergent event detection & logging
│   ├── UI/                      # Overlay, entity panel fragments
│   └── Configuration/           # Bindito configurators
├── Localizations/               # Trait names, mood descriptions
├── Blueprints/                  # Trait pool definitions
└── AssetBundles/                # UI assets (USS/UXML)
    └── Resources/
        └── UI/
```

## Building

Requires the [timberborn-modding](https://github.com/mechanistry/timberborn-modding) Unity project.
Place this folder in `Assets/Mods/BeaverBehaviorBreakdown/` and use the Mod Builder.

## License

MIT
