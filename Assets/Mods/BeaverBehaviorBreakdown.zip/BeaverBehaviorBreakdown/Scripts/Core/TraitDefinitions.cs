using System.Collections.Generic;

namespace Mods.BeaverBehaviorBreakdown.Core
{

    /// <summary>
    /// Static definitions of all personality traits in the mod.
    /// These could also be loaded from Blueprint JSON, but we define them here
    /// for clarity and to keep the initial version self-contained.
    /// </summary>
    public static class TraitDefinitions
    {

        public static IEnumerable<PersonalityTrait> GetAll()
        {
            // === WORK ETHIC ===
            yield return new PersonalityTrait
            {
                Id = "Workaholic",
                DisplayNameLocKey = "BBB.Trait.Workaholic.Name",
                DescriptionLocKey = "BBB.Trait.Workaholic.Desc",
                Category = TraitCategory.WorkEthic,
                WorkSpeedModifier = 1.3f,
                HungerRateModifier = 1.4f,
                SocialInfluenceStrength = 0.2f,
                LeadershipWeight = 0.3f
            };

            yield return new PersonalityTrait
            {
                Id = "Slacker",
                DisplayNameLocKey = "BBB.Trait.Slacker.Name",
                DescriptionLocKey = "BBB.Trait.Slacker.Desc",
                Category = TraitCategory.WorkEthic,
                WorkSpeedModifier = 0.6f,
                HungerRateModifier = 0.8f,
                SocialInfluenceStrength = 0.4f,  // Slacking is contagious
                MimicryTendency = 0.1f
            };

            yield return new PersonalityTrait
            {
                Id = "Perfectionist",
                DisplayNameLocKey = "BBB.Trait.Perfectionist.Name",
                DescriptionLocKey = "BBB.Trait.Perfectionist.Desc",
                Category = TraitCategory.WorkEthic,
                WorkSpeedModifier = 0.7f,  // Slower but...
                ConflictProneness = 0.5f,  // Gets annoyed by sloppy neighbors
                LeadershipWeight = 0.2f
            };

            yield return new PersonalityTrait
            {
                Id = "Procrastinator",
                DisplayNameLocKey = "BBB.Trait.Procrastinator.Name",
                DescriptionLocKey = "BBB.Trait.Procrastinator.Desc",
                Category = TraitCategory.WorkEthic,
                WorkSpeedModifier = 0.4f,
                MovementSpeedModifier = 0.8f,
                MimicryTendency = 0.6f  // Easily distracted by what others do
            };

            // === SOCIAL ===
            yield return new PersonalityTrait
            {
                Id = "NaturalLeader",
                DisplayNameLocKey = "BBB.Trait.NaturalLeader.Name",
                DescriptionLocKey = "BBB.Trait.NaturalLeader.Desc",
                Category = TraitCategory.Social,
                SocialInfluenceRadius = 12.0f,
                SocialInfluenceStrength = 0.6f,
                LeadershipWeight = 1.0f,
                ConflictProneness = 0.3f  // Leaders attract conflict
            };

            yield return new PersonalityTrait
            {
                Id = "Loner",
                DisplayNameLocKey = "BBB.Trait.Loner.Name",
                DescriptionLocKey = "BBB.Trait.Loner.Desc",
                Category = TraitCategory.Social,
                SocialInfluenceRadius = 1.0f,
                SocialInfluenceStrength = -0.2f,  // Repels social interaction
                WorkSpeedModifier = 1.15f,  // Works better alone
                ConflictProneness = 0.4f
            };

            yield return new PersonalityTrait
            {
                Id = "Gossip",
                DisplayNameLocKey = "BBB.Trait.Gossip.Name",
                DescriptionLocKey = "BBB.Trait.Gossip.Desc",
                Category = TraitCategory.Social,
                SocialInfluenceRadius = 15.0f,
                SocialInfluenceStrength = 0.3f,
                WorkSpeedModifier = 0.85f,  // Too busy chatting
                MimicryTendency = 0.8f  // Spreads behaviors rapidly
            };

            yield return new PersonalityTrait
            {
                Id = "Contrarian",
                DisplayNameLocKey = "BBB.Trait.Contrarian.Name",
                DescriptionLocKey = "BBB.Trait.Contrarian.Desc",
                Category = TraitCategory.Social,
                SocialInfluenceStrength = -0.4f,  // Actively resists influence
                ConflictProneness = 0.7f,
                MimicryTendency = -0.5f  // Does the opposite
            };

            // === PHYSICAL ===
            yield return new PersonalityTrait
            {
                Id = "Hyperactive",
                DisplayNameLocKey = "BBB.Trait.Hyperactive.Name",
                DescriptionLocKey = "BBB.Trait.Hyperactive.Desc",
                Category = TraitCategory.Physical,
                MovementSpeedModifier = 1.4f,
                HungerRateModifier = 1.3f,
                SleepEfficiencyModifier = 0.7f,
                SocialInfluenceStrength = 0.2f
            };

            yield return new PersonalityTrait
            {
                Id = "Glutton",
                DisplayNameLocKey = "BBB.Trait.Glutton.Name",
                DescriptionLocKey = "BBB.Trait.Glutton.Desc",
                Category = TraitCategory.Physical,
                HungerRateModifier = 1.8f,
                WorkSpeedModifier = 1.1f,  // Well-fed = motivated
                MovementSpeedModifier = 0.9f
            };

            yield return new PersonalityTrait
            {
                Id = "Narcoleptic",
                DisplayNameLocKey = "BBB.Trait.Narcoleptic.Name",
                DescriptionLocKey = "BBB.Trait.Narcoleptic.Desc",
                Category = TraitCategory.Physical,
                SleepEfficiencyModifier = 1.5f,  // Sleeps great... too much
                WorkSpeedModifier = 0.75f,
                MimicryTendency = 0.3f  // Yawning is contagious
            };

            yield return new PersonalityTrait
            {
                Id = "IronBladder",
                DisplayNameLocKey = "BBB.Trait.IronBladder.Name",
                DescriptionLocKey = "BBB.Trait.IronBladder.Desc",
                Category = TraitCategory.Physical,
                WorkSpeedModifier = 1.1f,
                MovementSpeedModifier = 1.05f,
                HungerRateModifier = 0.85f
            };

            // === MENTAL ===
            yield return new PersonalityTrait
            {
                Id = "Paranoid",
                DisplayNameLocKey = "BBB.Trait.Paranoid.Name",
                DescriptionLocKey = "BBB.Trait.Paranoid.Desc",
                Category = TraitCategory.Mental,
                MovementSpeedModifier = 1.2f,  // Always looking over shoulder
                WorkSpeedModifier = 0.8f,
                ConflictProneness = 0.6f,
                SocialInfluenceRadius = 8.0f  // Hyper-aware of surroundings
            };

            yield return new PersonalityTrait
            {
                Id = "Optimist",
                DisplayNameLocKey = "BBB.Trait.Optimist.Name",
                DescriptionLocKey = "BBB.Trait.Optimist.Desc",
                Category = TraitCategory.Mental,
                WorkSpeedModifier = 1.1f,
                SocialInfluenceStrength = 0.3f,
                SleepEfficiencyModifier = 1.1f,
                ConflictProneness = -0.2f  // Hard to upset
            };

            yield return new PersonalityTrait
            {
                Id = "Dramatic",
                DisplayNameLocKey = "BBB.Trait.Dramatic.Name",
                DescriptionLocKey = "BBB.Trait.Dramatic.Desc",
                Category = TraitCategory.Mental,
                SocialInfluenceStrength = 0.5f,
                SocialInfluenceRadius = 10.0f,
                ConflictProneness = 0.4f,
                MimicryTendency = 0.2f
            };

            // === CHAOTIC (rare) ===
            yield return new PersonalityTrait
            {
                Id = "ChaoticNeutral",
                DisplayNameLocKey = "BBB.Trait.ChaoticNeutral.Name",
                DescriptionLocKey = "BBB.Trait.ChaoticNeutral.Desc",
                Category = TraitCategory.Chaotic,
                WorkSpeedModifier = 1.0f,  // Unpredictable — modified at runtime
                SocialInfluenceStrength = 0.5f,
                ConflictProneness = 0.5f,
                MimicryTendency = 0.5f,
                LeadershipWeight = 0.5f
            };

            yield return new PersonalityTrait
            {
                Id = "Copycat",
                DisplayNameLocKey = "BBB.Trait.Copycat.Name",
                DescriptionLocKey = "BBB.Trait.Copycat.Desc",
                Category = TraitCategory.Chaotic,
                MimicryTendency = 1.0f,  // Maximum mimicry
                SocialInfluenceRadius = 8.0f,
                WorkSpeedModifier = 0.9f
            };

            yield return new PersonalityTrait
            {
                Id = "Anarchist",
                DisplayNameLocKey = "BBB.Trait.Anarchist.Name",
                DescriptionLocKey = "BBB.Trait.Anarchist.Desc",
                Category = TraitCategory.Chaotic,
                ConflictProneness = 1.0f,
                SocialInfluenceStrength = 0.7f,
                LeadershipWeight = -0.5f,  // Anti-leader
                MimicryTendency = -1.0f   // Never copies, always disrupts
            };
        }
    }
}
