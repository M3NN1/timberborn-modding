namespace Mods.BeaverBehaviorBreakdown.Core
{

    /// <summary>
    /// Defines a single personality trait with its behavioral modifiers.
    /// Traits are immutable data — they describe what a trait DOES, not who has it.
    /// </summary>
    public record PersonalityTrait
    {
        public string Id { get; init; }
        public string DisplayNameLocKey { get; init; }
        public string DescriptionLocKey { get; init; }
        public TraitCategory Category { get; init; }

        // Behavioral modifiers (multipliers, 1.0 = no change)
        public float WorkSpeedModifier { get; init; } = 1.0f;
        public float MovementSpeedModifier { get; init; } = 1.0f;
        public float HungerRateModifier { get; init; } = 1.0f;
        public float SleepEfficiencyModifier { get; init; } = 1.0f;
        public float SocialInfluenceRadius { get; init; } = 5.0f;
        public float SocialInfluenceStrength { get; init; } = 0.0f;

        // Interaction weights — how this trait reacts to others
        public float ConflictProneness { get; init; } = 0.0f;
        public float MimicryTendency { get; init; } = 0.0f;
        public float LeadershipWeight { get; init; } = 0.0f;
    }
}
