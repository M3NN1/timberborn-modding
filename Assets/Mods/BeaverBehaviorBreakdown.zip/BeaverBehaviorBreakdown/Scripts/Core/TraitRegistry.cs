using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;

namespace Mods.BeaverBehaviorBreakdown.Core
{

    /// <summary>
    /// Central registry of all available personality traits.
    /// Loaded once at game start, immutable thereafter.
    /// </summary>
    public class TraitRegistry
    {

        private readonly ImmutableDictionary<string, PersonalityTrait> _traits;

        public TraitRegistry(IEnumerable<PersonalityTrait> traits)
        {
            _traits = traits.ToImmutableDictionary(t => t.Id);
        }

        public PersonalityTrait Get(string traitId)
        {
            return _traits.TryGetValue(traitId, out var trait) ? trait : null;
        }

        public IReadOnlyList<PersonalityTrait> GetByCategory(TraitCategory category)
        {
            return _traits.Values.Where(t => t.Category == category).ToList();
        }

        public IReadOnlyList<PersonalityTrait> All => _traits.Values.ToList();
    }
}
