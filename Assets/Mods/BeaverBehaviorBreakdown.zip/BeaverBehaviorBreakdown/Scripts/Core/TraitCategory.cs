namespace Mods.BeaverBehaviorBreakdown.Core
{

    /// <summary>
    /// Categories group traits for assignment rules.
    /// A beaver gets one trait per category (or none if unlucky).
    /// </summary>
    public enum TraitCategory
    {
        /// Work ethic and productivity
        WorkEthic,
        /// Social behavior and interaction style
        Social,
        /// Physical quirks affecting movement/needs
        Physical,
        /// Mental state affecting decision-making
        Mental,
        /// Wild card — rare traits that break normal rules
        Chaotic
    }
}
