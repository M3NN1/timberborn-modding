namespace Mods.BeaverBehaviorBreakdown.Core
{

    /// <summary>
    /// Current emotional state of a beaver, derived from trait interactions
    /// and social context. Moods are transient, traits are permanent.
    /// </summary>
    public enum MoodState
    {
        Neutral,
        Inspired,       // Working near a leader or after positive social interaction
        Frustrated,     // Conflicting traits nearby, needs unmet
        Mischievous,    // Chaotic trait activated, about to do something unexpected
        Exhausted,      // Overworked due to trait modifiers stacking
        Euphoric,       // Rare — multiple positive interactions converging
        Rebellious,     // Conflict with nearby leader, refusing normal behavior
        Panicked        // Too many conflicting social signals at once
    }
}
