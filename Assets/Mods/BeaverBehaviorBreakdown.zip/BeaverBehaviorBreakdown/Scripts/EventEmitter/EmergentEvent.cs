using Mods.BeaverBehaviorBreakdown.TraitSystem;
using System.Collections.Generic;

namespace Mods.BeaverBehaviorBreakdown.EventEmitter
{

    /// <summary>
    /// Represents an emergent event detected by the social system.
    /// These are NOT scripted — they arise naturally from trait interactions.
    /// </summary>
    public class EmergentEvent
    {
        public EmergentEventType Type { get; init; }
        public BeaverPersonality SourceBeaver { get; init; }
        public List<BeaverPersonality> AffectedBeavers { get; init; } = new();
        public string Description { get; init; }
        public float Timestamp { get; init; }
    }

    public enum EmergentEventType
    {
        /// 3+ beavers caught in the same mood cascade
        MoodChainReaction,
        /// Two NaturalLeaders competing for influence
        LeadershipChallenge,
        /// Gossip spreading mood rapidly through social network
        GossipSpiral,
        /// Anarchist successfully disrupting a productive group
        AnarchyEvent,
        /// Entire workplace hit by Slacker contagion
        ProductivityCollapse,
        /// Copycat created a feedback loop
        MimicryLoop,
        /// Loner forced into crowded space — conflict erupts
        LonerOverload,
        /// Rare: all beavers in area reach Euphoric simultaneously
        CollectiveEuphoria,
        /// Paranoid beaver's panic spreads to others
        PanicContagion
    }
}
