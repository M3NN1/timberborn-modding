using System;
using System.Collections.Generic;
using System.Linq;
using Timberborn.SingletonSystem;
using UnityEngine;

namespace Mods.BeaverBehaviorBreakdown.EventEmitter
{

    /// <summary>
    /// Collects and surfaces emergent events from the social system.
    /// Maintains a rolling log and notifies subscribers (UI, console).
    /// 
    /// Events are never scripted — they're pattern-detected from actual
    /// trait interactions happening in the colony.
    /// </summary>
    public class EmergentEventEmitter : ILoadableSingleton
    {

        private const int MaxEventLog = 50;

        private readonly List<EmergentEvent> _eventLog = new();
        private readonly Dictionary<EmergentEventType, float> _cooldowns = new();
        private const float CooldownDuration = 10f; // Don't spam same event type

        public event Action<EmergentEvent> OnEventEmitted;

        public IReadOnlyList<EmergentEvent> RecentEvents => _eventLog;

        public void Load()
        {
            _eventLog.Clear();
            _cooldowns.Clear();
        }

        public void Emit(EmergentEvent evt)
        {
            // Cooldown check — prevent event spam
            if (_cooldowns.TryGetValue(evt.Type, out float lastTime))
            {
                if (Time.time - lastTime < CooldownDuration) return;
            }

            evt = new EmergentEvent
            {
                Type = evt.Type,
                SourceBeaver = evt.SourceBeaver,
                AffectedBeavers = evt.AffectedBeavers,
                Description = evt.Description,
                Timestamp = Time.time
            };
            _eventLog.Add(evt);
            _cooldowns[evt.Type] = Time.time;

            // Trim log
            while (_eventLog.Count > MaxEventLog)
            {
                _eventLog.RemoveAt(0);
            }

            Debug.Log($"[BBB Event] {evt.Type}: {evt.Description}");
            OnEventEmitted?.Invoke(evt);
        }

        public IEnumerable<EmergentEvent> GetEventsByType(EmergentEventType type)
        {
            return _eventLog.Where(e => e.Type == type);
        }

        public EmergentEvent GetMostRecent()
        {
            return _eventLog.LastOrDefault();
        }
    }
}
