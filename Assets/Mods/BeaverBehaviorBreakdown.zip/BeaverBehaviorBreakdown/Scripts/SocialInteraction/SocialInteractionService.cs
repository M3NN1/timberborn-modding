using Mods.BeaverBehaviorBreakdown.Core;
using Mods.BeaverBehaviorBreakdown.EventEmitter;
using Mods.BeaverBehaviorBreakdown.TraitSystem;
using System.Collections.Generic;
using System.Linq;
using Timberborn.SingletonSystem;
using UnityEngine;

namespace Mods.BeaverBehaviorBreakdown.SocialInteraction
{

    /// <summary>
    /// Core social propagation system. Every tick, beavers within influence radius
    /// affect each other's moods based on trait interactions.
    /// 
    /// This is where emergent chaos happens:
    /// - A NaturalLeader inspires nearby workers → productivity spike
    /// - A Gossip spreads a Slacker's laziness → entire workshop slows down
    /// - An Anarchist near a Leader → both get Frustrated → conflict event
    /// - A Copycat mimics a Hyperactive beaver → exhausts itself
    /// </summary>
    public class SocialInteractionService : IUpdatableSingleton
    {

        private readonly BeaverPersonalityRegistry _personalityRegistry;
        private readonly EmergentEventEmitter _eventEmitter;

        private float _tickTimer = 0f;
        private const float TickInterval = 2.0f; // Process social interactions every 2 seconds

        public SocialInteractionService(BeaverPersonalityRegistry personalityRegistry,
                                         EmergentEventEmitter eventEmitter)
        {
            _personalityRegistry = personalityRegistry;
            _eventEmitter = eventEmitter;
        }

        public void UpdateSingleton()
        {
            _tickTimer += Time.deltaTime;
            if (_tickTimer < TickInterval) return;
            _tickTimer = 0f;

            ProcessSocialInteractions();
        }

        private void ProcessSocialInteractions()
        {
            var allBeavers = _personalityRegistry.GetAllActive();

            foreach (var beaver in allBeavers)
            {
                var position = beaver.Transform.position;
                var nearbyBeavers = GetBeaversInRadius(allBeavers, beaver, position);

                if (nearbyBeavers.Count == 0)
                {
                    // Loners thrive alone
                    if (beaver.HasTrait("Loner"))
                    {
                        beaver.SetMood(MoodState.Inspired, 0.3f);
                    }
                    else
                    {
                        beaver.SetMood(MoodState.Neutral, 0f);
                    }
                    continue;
                }

                var newMood = CalculateMoodFromInteractions(beaver, nearbyBeavers);
                beaver.SetMood(newMood.mood, newMood.intensity);

                // Check for emergent events
                DetectEmergentEvents(beaver, nearbyBeavers);
            }
        }

        private List<BeaverPersonality> GetBeaversInRadius(
            IReadOnlyList<BeaverPersonality> all,
            BeaverPersonality center,
            Vector3 position)
        {

            float maxRadius = center.Traits.Max(t => t.SocialInfluenceRadius);

            return all
              .Where(b => b != center)
              .Where(b => Vector3.Distance(b.Transform.position, position) <= maxRadius)
              .ToList();
        }

        private (MoodState mood, float intensity) CalculateMoodFromInteractions(
            BeaverPersonality beaver,
            List<BeaverPersonality> nearby)
        {

            float positiveInfluence = 0f;
            float negativeInfluence = 0f;
            float chaosInfluence = 0f;
            int conflictCount = 0;

            foreach (var other in nearby)
            {
                float distance = Vector3.Distance(
                  beaver.Transform.position,
                  other.Transform.position);

                foreach (var otherTrait in other.Traits)
                {
                    float distanceFalloff = 1.0f - (distance / otherTrait.SocialInfluenceRadius);
                    if (distanceFalloff <= 0) continue;

                    float influence = otherTrait.SocialInfluenceStrength * distanceFalloff;

                    // Mimicry: beaver copies nearby behavior
                    float mimicryFactor = beaver.Traits.Sum(t => t.MimicryTendency);
                    influence *= (1.0f + Mathf.Abs(mimicryFactor));

                    // Conflict detection
                    float conflictChance = CalculateConflictChance(beaver, other);
                    if (conflictChance > 0.5f)
                    {
                        conflictCount++;
                        negativeInfluence += conflictChance * distanceFalloff;
                    }

                    if (influence > 0) positiveInfluence += influence;
                    else negativeInfluence += Mathf.Abs(influence);

                    // Chaotic traits add chaos
                    if (otherTrait.Category == TraitCategory.Chaotic)
                    {
                        chaosInfluence += distanceFalloff * 0.5f;
                    }
                }
            }

            // Determine resulting mood
            if (chaosInfluence > 0.8f)
            {
                return (MoodState.Panicked, Mathf.Clamp01(chaosInfluence));
            }
            if (conflictCount >= 3)
            {
                return (MoodState.Panicked, 0.8f);
            }
            if (negativeInfluence > positiveInfluence * 2)
            {
                return (MoodState.Frustrated, Mathf.Clamp01(negativeInfluence));
            }
            if (conflictCount > 0 && beaver.Traits.Any(t => t.ConflictProneness > 0.5f))
            {
                return (MoodState.Rebellious, Mathf.Clamp01(negativeInfluence));
            }
            if (positiveInfluence > 1.5f)
            {
                return (MoodState.Euphoric, Mathf.Clamp01(positiveInfluence / 2f));
            }
            if (positiveInfluence > 0.5f)
            {
                return (MoodState.Inspired, Mathf.Clamp01(positiveInfluence));
            }
            if (chaosInfluence > 0.3f)
            {
                return (MoodState.Mischievous, Mathf.Clamp01(chaosInfluence));
            }

            return (MoodState.Neutral, 0f);
        }

        private float CalculateConflictChance(BeaverPersonality a, BeaverPersonality b)
        {
            float conflictA = a.Traits.Sum(t => t.ConflictProneness);
            float conflictB = b.Traits.Sum(t => t.ConflictProneness);

            // Leaders vs Anarchists = guaranteed conflict
            bool leaderVsAnarchist =
              (a.HasTrait("NaturalLeader") && b.HasTrait("Anarchist")) ||
              (a.HasTrait("Anarchist") && b.HasTrait("NaturalLeader"));
            if (leaderVsAnarchist) return 1.0f;

            // Perfectionists hate Slackers
            bool perfVsSlack =
              (a.HasTrait("Perfectionist") && b.HasTrait("Slacker")) ||
              (a.HasTrait("Slacker") && b.HasTrait("Perfectionist"));
            if (perfVsSlack) return 0.8f;

            return Mathf.Clamp01((conflictA + conflictB) / 4f);
        }

        private void DetectEmergentEvents(BeaverPersonality beaver,
                                           List<BeaverPersonality> nearby)
        {
            // Chain reaction: 3+ beavers in same mood = event
            var sameMoodCount = nearby.Count(b => b.CurrentMood == beaver.CurrentMood);
            if (sameMoodCount >= 3)
            {
                _eventEmitter.Emit(new EmergentEvent
                {
                    Type = EmergentEventType.MoodChainReaction,
                    SourceBeaver = beaver,
                    AffectedBeavers = nearby.Where(b => b.CurrentMood == beaver.CurrentMood).ToList(),
                    Description = $"Mood cascade: {sameMoodCount + 1} beavers are {beaver.CurrentMood}!"
                });
            }

            // Leadership challenge: two leaders in range
            if (beaver.HasTrait("NaturalLeader"))
            {
                var otherLeaders = nearby.Where(b => b.HasTrait("NaturalLeader")).ToList();
                if (otherLeaders.Count > 0)
                {
                    _eventEmitter.Emit(new EmergentEvent
                    {
                        Type = EmergentEventType.LeadershipChallenge,
                        SourceBeaver = beaver,
                        AffectedBeavers = otherLeaders,
                        Description = "Leadership clash! Two leaders compete for influence."
                    });
                }
            }

            // Gossip spiral: Gossip + 2 other social beavers = rapid mood spread
            if (beaver.HasTrait("Gossip") && beaver.CurrentMood != MoodState.Neutral)
            {
                var socialBeavers = nearby.Where(b =>
                  b.HasTraitInCategory(TraitCategory.Social)).ToList();
                if (socialBeavers.Count >= 2)
                {
                    _eventEmitter.Emit(new EmergentEvent
                    {
                        Type = EmergentEventType.GossipSpiral,
                        SourceBeaver = beaver,
                        AffectedBeavers = socialBeavers,
                        Description = $"Gossip spiral! {beaver.CurrentMood} spreading rapidly."
                    });
                }
            }
        }
    }
}
