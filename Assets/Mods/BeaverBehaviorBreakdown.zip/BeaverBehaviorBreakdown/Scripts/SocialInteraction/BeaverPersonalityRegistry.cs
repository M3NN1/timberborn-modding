using Mods.BeaverBehaviorBreakdown.TraitSystem;
using System.Collections.Generic;
using Timberborn.SingletonSystem;

namespace Mods.BeaverBehaviorBreakdown.SocialInteraction
{

    /// <summary>
    /// Tracks all active beavers with personalities for the social system.
    /// Beavers register/unregister as they spawn/die.
    /// </summary>
    public class BeaverPersonalityRegistry : ILoadableSingleton
    {

        private readonly List<BeaverPersonality> _activeBeavers = new();

        public void Load()
        {
            _activeBeavers.Clear();
        }

        public void Register(BeaverPersonality personality)
        {
            if (!_activeBeavers.Contains(personality))
            {
                _activeBeavers.Add(personality);
            }
        }

        public void Unregister(BeaverPersonality personality)
        {
            _activeBeavers.Remove(personality);
        }

        public IReadOnlyList<BeaverPersonality> GetAllActive() => _activeBeavers;

        public int ActiveCount => _activeBeavers.Count;
    }
}
