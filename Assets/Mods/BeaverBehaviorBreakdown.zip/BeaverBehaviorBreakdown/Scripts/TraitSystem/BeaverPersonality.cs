using Mods.BeaverBehaviorBreakdown.Core;
using System.Collections.Generic;
using System.Linq;
using Timberborn.BaseComponentSystem;
using Timberborn.EntitySystem;
using Timberborn.Persistence;
using Timberborn.WorldPersistence;
using UnityEngine;

namespace Mods.BeaverBehaviorBreakdown.TraitSystem
{

    /// <summary>
    /// Per-beaver component that stores assigned personality traits and current mood.
    /// Traits are assigned once on spawn and persist across save/load.
    /// Mood is recalculated each frame based on social context.
    /// </summary>
    public class BeaverPersonality : BaseComponent,
                                      IInitializableEntity,
                                      IPersistentEntity
    {

        private static readonly ComponentKey BeaverPersonalityKey = new("BeaverPersonality");
        private static readonly ListKey<string> TraitIdsKey = new("TraitIds");
        private static readonly PropertyKey<string> MoodKey = new("Mood");
        private readonly TraitAssigner _traitAssigner;
        private readonly TraitRegistry _traitRegistry;

        private List<PersonalityTrait> _traits = new();
        private MoodState _currentMood = MoodState.Neutral;
        private float _moodIntensity = 0f;

        public IReadOnlyList<PersonalityTrait> Traits => _traits;
        public MoodState CurrentMood => _currentMood;
        public float MoodIntensity => _moodIntensity;

        public BeaverPersonality(TraitAssigner traitAssigner,
                                  TraitRegistry traitRegistry)
        {
            _traitAssigner = traitAssigner;
            _traitRegistry = traitRegistry;
        }

        public void Initialize()
        {
            if (_traits.Count == 0)
            {
                _traits = _traitAssigner.AssignTraits(this).ToList();
                Debug.Log($"[BBB] Beaver {GameObject.name} assigned traits: " +
                          string.Join(", ", _traits.Select(t => t.Id)));
            }
        }

        public void InitializeEntity()
        {
            Initialize();
        }

        public void SetMood(MoodState mood, float intensity)
        {
            _currentMood = mood;
            _moodIntensity = Mathf.Clamp01(intensity);
        }

        public bool HasTrait(string traitId)
        {
            return _traits.Any(t => t.Id == traitId);
        }

        public bool HasTraitInCategory(TraitCategory category)
        {
            return _traits.Any(t => t.Category == category);
        }

        /// <summary>
        /// Aggregate modifier for a given stat across all traits.
        /// Multiplies all trait modifiers together.
        /// </summary>
        public float GetAggregateModifier(System.Func<PersonalityTrait, float> selector)
        {
            float result = 1.0f;
            foreach (var trait in _traits)
            {
                result *= selector(trait);
            }
            return result;
        }

        public void Save(IEntitySaver entitySaver)
        {
            var component = entitySaver.GetComponent(BeaverPersonalityKey);
            component.Set(TraitIdsKey, _traits.Select(t => t.Id).ToList());
            component.Set(MoodKey, _currentMood.ToString());
        }

        public void Load(IEntityLoader entityLoader)
        {
            if (!entityLoader.TryGetComponent(BeaverPersonalityKey, out var component)) return;

            var traitIds = component.Get(TraitIdsKey);
            _traits = traitIds
              .Select(id => _traitRegistry.Get(id))
              .Where(t => t != null)
              .ToList();

            string moodStr;
            if (component.Has(MoodKey))
            {
                moodStr = component.Get(MoodKey);
            }
            else
            {
                moodStr = MoodState.Neutral.ToString();
            }
            if (System.Enum.TryParse<MoodState>(moodStr, out var mood))
            {
                _currentMood = mood;
            }
        }
    }
}
