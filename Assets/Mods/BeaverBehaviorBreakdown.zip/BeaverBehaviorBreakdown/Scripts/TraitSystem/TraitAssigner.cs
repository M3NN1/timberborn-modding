using Mods.BeaverBehaviorBreakdown.Core;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mods.BeaverBehaviorBreakdown.TraitSystem
{

    /// <summary>
    /// Assigns personality traits to beavers on spawn.
    /// Uses weighted randomness — no two colonies will develop the same way.
    /// </summary>
    public class TraitAssigner
    {

        private readonly TraitRegistry _traitRegistry;
        private readonly System.Random _random = new();

        public TraitAssigner(TraitRegistry traitRegistry)
        {
            _traitRegistry = traitRegistry;
        }

        public IEnumerable<PersonalityTrait> AssignTraits(BeaverPersonality beaver)
        {
            var assigned = new List<PersonalityTrait>();
            var categories = Enum.GetValues(typeof(TraitCategory)).Cast<TraitCategory>().ToList();

            // Each beaver gets 1-3 traits from different categories
            int traitCount = _random.Next(1, 4);

            // Shuffle categories for variety
            categories = categories.OrderBy(_ => _random.Next()).ToList();

            foreach (var category in categories.Take(traitCount))
            {
                // Chaotic traits are rare
                if (category == TraitCategory.Chaotic && _random.NextDouble() > 0.1)
                {
                    continue;
                }

                var candidates = _traitRegistry.GetByCategory(category);
                if (candidates.Count == 0) continue;

                var chosen = candidates[_random.Next(candidates.Count)];
                assigned.Add(chosen);
            }

            // Guarantee at least one trait
            if (assigned.Count == 0)
            {
                var allTraits = _traitRegistry.All;
                var nonChaotic = allTraits.Where(t => t.Category != TraitCategory.Chaotic).ToList();
                if (nonChaotic.Count > 0)
                {
                    assigned.Add(nonChaotic[_random.Next(nonChaotic.Count)]);
                }
            }

            return assigned;
        }
    }
}
