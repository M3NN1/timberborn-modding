using System.Collections.Immutable;
using Timberborn.BlueprintSystem;

namespace Mods.BeaverBehaviorBreakdown.TraitSystem
{

    /// <summary>
    /// Blueprint Spec that marks an entity as capable of having personality traits.
    /// Attached to beaver prefabs via decoration.
    /// </summary>
    internal record BeaverPersonalitySpec : ComponentSpec
    {

        /// <summary>
        /// Maximum number of traits a beaver can have simultaneously.
        /// </summary>
        [Serialize]
        public int MaxTraits { get; init; } = 3;

        /// <summary>
        /// Chance (0-1) of receiving a Chaotic trait on spawn.
        /// </summary>
        [Serialize]
        public float ChaoticTraitChance { get; init; } = 0.1f;

        /// <summary>
        /// Trait IDs that are forced on this entity (for special beavers).
        /// </summary>
        [Serialize]
        public ImmutableArray<string> ForcedTraitIds { get; init; } = ImmutableArray<string>.Empty;
    }
}
