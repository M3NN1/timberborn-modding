using Mods.BeaverBehaviorBreakdown.Core;
using Mods.BeaverBehaviorBreakdown.TraitSystem;
using UnityEngine;

namespace Mods.BeaverBehaviorBreakdown.BehaviorModifiers
{

    /// <summary>
    /// Calculates effective stat modifiers for a beaver based on their traits,
    /// current mood, and nearby social influences.
    /// 
    /// This is where traits become gameplay — a Workaholic next to a Slacker
    /// might get Frustrated (reducing their bonus), while a Gossip near a
    /// NaturalLeader amplifies the leader's influence radius.
    /// </summary>
    public class BehaviorModifierService
    {

        /// <summary>
        /// Get effective work speed for a beaver, considering traits + mood.
        /// </summary>
        public float GetEffectiveWorkSpeed(BeaverPersonality personality)
        {
            float baseModifier = personality.GetAggregateModifier(t => t.WorkSpeedModifier);
            float moodModifier = GetMoodWorkModifier(personality.CurrentMood, personality.MoodIntensity);
            return Mathf.Clamp(baseModifier * moodModifier, 0.2f, 3.0f);
        }

        /// <summary>
        /// Get effective movement speed modifier.
        /// </summary>
        public float GetEffectiveMovementSpeed(BeaverPersonality personality)
        {
            float baseModifier = personality.GetAggregateModifier(t => t.MovementSpeedModifier);
            float moodModifier = personality.CurrentMood == MoodState.Panicked ? 1.5f :
                                 personality.CurrentMood == MoodState.Exhausted ? 0.7f : 1.0f;
            return Mathf.Clamp(baseModifier * moodModifier, 0.3f, 2.5f);
        }

        /// <summary>
        /// Get effective hunger rate modifier.
        /// </summary>
        public float GetEffectiveHungerRate(BeaverPersonality personality)
        {
            float baseModifier = personality.GetAggregateModifier(t => t.HungerRateModifier);
            // Stressed beavers eat more
            if (personality.CurrentMood == MoodState.Frustrated ||
                personality.CurrentMood == MoodState.Panicked)
            {
                baseModifier *= 1.2f;
            }
            return Mathf.Clamp(baseModifier, 0.5f, 3.0f);
        }

        /// <summary>
        /// Get effective sleep efficiency.
        /// </summary>
        public float GetEffectiveSleepEfficiency(BeaverPersonality personality)
        {
            float baseModifier = personality.GetAggregateModifier(t => t.SleepEfficiencyModifier);
            // Euphoric beavers sleep like babies
            if (personality.CurrentMood == MoodState.Euphoric)
            {
                baseModifier *= 1.3f;
            }
            return Mathf.Clamp(baseModifier, 0.3f, 2.0f);
        }

        private float GetMoodWorkModifier(MoodState mood, float intensity)
        {
            return mood switch
            {
                MoodState.Inspired => 1.0f + (0.3f * intensity),
                MoodState.Frustrated => 1.0f - (0.2f * intensity),
                MoodState.Mischievous => 0.8f,  // Distracted by mischief
                MoodState.Exhausted => 0.5f,
                MoodState.Euphoric => 1.0f + (0.5f * intensity),
                MoodState.Rebellious => 0.4f,   // Actively resisting work
                MoodState.Panicked => 0.3f,
                _ => 1.0f
            };
        }
    }
}
