using Bindito.Core;
using Mods.BeaverBehaviorBreakdown.BehaviorModifiers;
using Mods.BeaverBehaviorBreakdown.Core;
using Mods.BeaverBehaviorBreakdown.EventEmitter;
using Mods.BeaverBehaviorBreakdown.SocialInteraction;
using Mods.BeaverBehaviorBreakdown.TraitSystem;
using Mods.BeaverBehaviorBreakdown.UI;
using Timberborn.EntityPanelSystem;
using Timberborn.TemplateInstantiation;

namespace Mods.BeaverBehaviorBreakdown.Configuration
{

    /// <summary>
    /// Main Bindito configurator for the Beaver Behavior Breakdown mod.
    /// Registers all services, components, and UI fragments.
    /// </summary>
    [Context("Game")]
    public class BeaverBehaviorConfigurator : Configurator
    {

        protected override void Configure()
        {
            // Core
            Bind<TraitRegistry>().ToProvider(ProvideTraitRegistry).AsSingleton();
            Bind<TraitAssigner>().AsSingleton();

            // Behavior
            Bind<BehaviorModifierService>().AsSingleton();

            // Social
            Bind<BeaverPersonalityRegistry>().AsSingleton();
            Bind<SocialInteractionService>().AsSingleton();

            // Events
            Bind<EmergentEventEmitter>().AsSingleton();


            Bind<PersonalityPanelFragment>().AsSingleton();

            // UI
            Bind<EventLogOverlay>().AsSingleton();
            MultiBind<EntityPanelModule>().ToProvider<EntityPanelModuleProvider>().AsSingleton();

            Bind<BeaverPersonality>().AsTransient();

            // Component decoration — attach BeaverPersonality to all beaver entities
            MultiBind<TemplateModule>().ToProvider(ProvideTemplateModule).AsSingleton();
        }

        private static TraitRegistry ProvideTraitRegistry()
        {
            return new TraitRegistry(TraitDefinitions.GetAll());
        }

        private static TemplateModule ProvideTemplateModule()
        {
            var builder = new TemplateModule.Builder();
            builder.AddDecorator<BeaverPersonalitySpec, BeaverPersonality>();
            return builder.Build();
        }

        private class EntityPanelModuleProvider : IProvider<EntityPanelModule>
        {
            private readonly PersonalityPanelFragment _personalityPanelFragment;

            public EntityPanelModuleProvider(PersonalityPanelFragment personalityPanelFragment)
            {
                _personalityPanelFragment = personalityPanelFragment;
            }

            public EntityPanelModule Get()
            {
                var builder = new EntityPanelModule.Builder();
                builder.AddMiddleFragment(_personalityPanelFragment);
                return builder.Build();
            }
        }
    }
}
