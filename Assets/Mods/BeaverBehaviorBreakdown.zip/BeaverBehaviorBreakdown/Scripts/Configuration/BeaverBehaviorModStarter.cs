using Timberborn.ModManagerScene;
using UnityEngine;

namespace Mods.BeaverBehaviorBreakdown.Configuration
{

    /// <summary>
    /// Entry point for the mod. Called when the game first loads the DLL.
    /// </summary>
    public class BeaverBehaviorModStarter : IModStarter
    {

        public void StartMod(IModEnvironment modEnvironment)
        {
            Debug.Log("[BBB] Beaver Behavior Breakdown loaded! " +
                      "Personality chaos incoming...");
        }
    }
}
