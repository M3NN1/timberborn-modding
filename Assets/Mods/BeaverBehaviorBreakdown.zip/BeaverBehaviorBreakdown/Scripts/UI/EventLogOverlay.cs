using Mods.BeaverBehaviorBreakdown.EventEmitter;
using System.Collections.Generic;
using Timberborn.CoreUI;
using Timberborn.SingletonSystem;
using Timberborn.UILayoutSystem;
using UnityEngine.UIElements;

namespace Mods.BeaverBehaviorBreakdown.UI
{

    /// <summary>
    /// Floating overlay that shows recent emergent events.
    /// Fades events out after a few seconds. Non-intrusive — just surfaces
    /// the chaos happening in the colony.
    /// </summary>
    public class EventLogOverlay : ILoadableSingleton
    {

        private readonly UILayout _uiLayout;
        private readonly VisualElementLoader _visualElementLoader;
        private readonly EmergentEventEmitter _eventEmitter;

        private VisualElement _root;
        private VisualElement _eventContainer;
        private readonly Queue<VisualElement> _activeEntries = new();
        private const int MaxVisibleEvents = 5;

        public EventLogOverlay(UILayout uiLayout,
                                VisualElementLoader visualElementLoader,
                                EmergentEventEmitter eventEmitter)
        {
            _uiLayout = uiLayout;
            _visualElementLoader = visualElementLoader;
            _eventEmitter = eventEmitter;
        }

        public void Load()
        {
            _root = _visualElementLoader.LoadVisualElement("EventLogOverlay");
            _eventContainer = _root.Q<VisualElement>("EventContainer");
            _uiLayout.AddTopRight(_root, 10);

            _eventEmitter.OnEventEmitted += OnNewEvent;
        }

        private void OnNewEvent(EmergentEvent evt)
        {
            var entry = new Label
            {
                text = $"🦫 {GetEventIcon(evt.Type)} {evt.Description}"
            };
            entry.AddToClassList("bbb-event-entry");

            _eventContainer.Add(entry);
            _activeEntries.Enqueue(entry);

            // Remove oldest if over limit
            while (_activeEntries.Count > MaxVisibleEvents)
            {
                var oldest = _activeEntries.Dequeue();
                _eventContainer.Remove(oldest);
            }
        }

        private string GetEventIcon(EmergentEventType type)
        {
            return type switch
            {
                EmergentEventType.MoodChainReaction => "🌊",
                EmergentEventType.LeadershipChallenge => "⚔️",
                EmergentEventType.GossipSpiral => "🗣️",
                EmergentEventType.AnarchyEvent => "🏴",
                EmergentEventType.ProductivityCollapse => "📉",
                EmergentEventType.MimicryLoop => "🪞",
                EmergentEventType.LonerOverload => "💥",
                EmergentEventType.CollectiveEuphoria => "🎊",
                EmergentEventType.PanicContagion => "😱",
                _ => "❓"
            };
        }
    }
}
