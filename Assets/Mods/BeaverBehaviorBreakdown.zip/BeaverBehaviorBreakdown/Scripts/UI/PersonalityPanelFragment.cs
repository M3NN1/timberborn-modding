using Mods.BeaverBehaviorBreakdown.BehaviorModifiers;
using Mods.BeaverBehaviorBreakdown.Core;
using Mods.BeaverBehaviorBreakdown.TraitSystem;
using System.Linq;
using Timberborn.CoreUI;
using Timberborn.EntityPanelSystem;
using Timberborn.Localization;
using UnityEngine.UIElements;

namespace Mods.BeaverBehaviorBreakdown.UI
{

    /// <summary>
    /// Entity panel fragment that shows personality traits and current mood
    /// when a beaver is selected. Integrates into the existing entity panel.
    /// </summary>
    public class PersonalityPanelFragment : IEntityPanelFragment
    {

        private readonly VisualElementLoader _visualElementLoader;
        private readonly ILoc _loc;
        private readonly BehaviorModifierService _modifierService;

        private VisualElement _root;
        private Label _traitsLabel;
        private Label _moodLabel;
        private Label _modifiersLabel;
        private BeaverPersonality _currentPersonality;

        public PersonalityPanelFragment(VisualElementLoader visualElementLoader,
                                         ILoc loc,
                                         BehaviorModifierService modifierService)
        {
            _visualElementLoader = visualElementLoader;
            _loc = loc;
            _modifierService = modifierService;
        }

        public VisualElement InitializeFragment()
        {
            _root = _visualElementLoader.LoadVisualElement("BeaverPersonalityPanel");
            _traitsLabel = _root.Q<Label>("TraitsLabel");
            _moodLabel = _root.Q<Label>("MoodLabel");
            _modifiersLabel = _root.Q<Label>("ModifiersLabel");
            _root.visible = false;
            return _root;
        }

        public void ShowFragment(Timberborn.BaseComponentSystem.BaseComponent entity)
        {
            var personality = entity.GetComponent<BeaverPersonality>();
            if (personality == null)
            {
                _root.visible = false;
                return;
            }

            _currentPersonality = personality;
            _root.visible = true;
            UpdateDisplay();
        }

        public void ClearFragment()
        {
            _root.visible = false;
            _currentPersonality = null;
        }

        public void UpdateFragment()
        {
            if (_currentPersonality != null)
            {
                UpdateDisplay();
            }
        }

        private void UpdateDisplay()
        {
            // Traits
            var traitNames = string.Join(", ",
              _currentPersonality.Traits.Select(t => _loc.T(t.DisplayNameLocKey)));
            _traitsLabel.text = $"Traits: {traitNames}";

            // Mood
            var moodText = GetMoodDisplayText(_currentPersonality.CurrentMood);
            var intensity = _currentPersonality.MoodIntensity;
            _moodLabel.text = $"Mood: {moodText} ({intensity:P0})";

            // Active modifiers
            float workSpeed = _modifierService.GetEffectiveWorkSpeed(_currentPersonality);
            float moveSpeed = _modifierService.GetEffectiveMovementSpeed(_currentPersonality);
            _modifiersLabel.text = $"Work: {workSpeed:F1}x | Move: {moveSpeed:F1}x";
        }

        private string GetMoodDisplayText(MoodState mood)
        {
            return mood switch
            {
                MoodState.Inspired => "✨ Inspired",
                MoodState.Frustrated => "😤 Frustrated",
                MoodState.Mischievous => "😈 Mischievous",
                MoodState.Exhausted => "😴 Exhausted",
                MoodState.Euphoric => "🎉 Euphoric",
                MoodState.Rebellious => "✊ Rebellious",
                MoodState.Panicked => "😱 Panicked",
                _ => "😐 Neutral"
            };
        }
    }
}
