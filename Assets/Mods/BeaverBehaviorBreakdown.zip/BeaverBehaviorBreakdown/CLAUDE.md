# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Context

**Timberborn mod** adds persistent personality traits to every beaver, creating emergent colony behavior through trait interactions and social propagation. Humor emerges from systems colliding, not scripted events.

## Build & Development

- Requires [timberborn-modding](https://github.com/mechanistry/timberborn-modding) project
- Place this folder in `Assets/Mods/BeaverBehaviorBreakdown/` and use the Mod Builder
- Unity version: 6000.3.6f1
- .NET Target: .NET Standard 2.1
- Main build project: `../BeaverBehaviorBreakdown.csproj`
- Assembly definition: `Assets/Mods/BeaverBehaviorBreakdown/Scripts/BeaverBehaviorBreakdown.asmdef`

## Architecture

**Pattern:** Timberborn Bindito DI framework with decoration system.

```
┌─────────────────────────────────────────────────────────────────┐
│                    Game Loop (per tick)                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌───────────┐    ┌───────────────────┐                        │
│  │ Trait System │───▶│ Behavior Modifiers  │                        │
│  │ (per beaver) │    │ (work, move, needs) │                        │
│  └───────┬────┘    └───────────────────┘                        │
│          │                                                        │
│          ▼                                                        │
│  ┌───────────────┐    ┌───────┐                                   │
│  │ Social Interaction │───▶│ Event Emitter│                                   │
│  └───────┬───────┘    └───────┘                                   │
│          │                                                            │
│          ▼                                                            │
│  ┌───────────────┐                                              │
│  │ UI Overlay    │                                              │
│  │ (panel + log) │                                              │
│  └───────────────┘                                              │
└───────────────────────────────────────────────────────────────────┘
```

### Key Patterns

| Pattern | Usage |
|---------|-------|
| `[Context("Game")]` | Bindito configurator attribute for all systems |
| `BaseComponent` classes | Per-beaver behavior (implemented via `BeaverPersonalitySpec`) |
| `ComponentSpec` records | Blueprint-driven trait definitions |
| `ILoadableSingleton` / `IUpdatableSingleton` | Global services in DI container |
| Template decoration | Attach `BeaverPersonality` to beaver entities at runtime |

## Core Systems

| System | Responsibility |
|--------|----------------|
| **Trait System** (`Scripts/TraitSystem/`) | Assigns and stores persistent personalities per beaver via `BeaverPersonality` |
| **Behavior Modifiers** (`Scripts/BehaviorModifiers/`) | Alters gameplay stats (work speed, needs, movement) per trait |
| **Social Interaction** (`Scripts/SocialInteraction/`) | Beavers affect each other (influence radius, mimicry, conflict) |
| **Event Emitter** (`Scripts/EventEmitter/`) | Detects and surfaces emergent outcomes |
| **UI Overlay** (`Scripts/UI/`) | Shows traits & moods on beaver selection (`PersonalityPanelFragment`, `EventLogOverlay`) |

## Key Data Structures

- `PersonalityTrait` record: Trait definitions with all behavioral modifiers
- `TraitCategory`: Enum grouping (WorkEthic, Social, Physical, Mental, Chaotic)
- `MoodState`: Enum for transient states (Inspired, Frustrated, Panicked, etc.)
- `BeaverPersonality`: Component storing per-beaver traits + mood state
- `BeaverPersonalitySpec`: Blueprint record defining trait pool

## Development Guidelines

- Traits use **multiplied modifiers** for stacking: `EffectiveStat = Base × Trait1 × Trait2 × ... × MoodMod`
- Moods are **recalculated every 2s** (transient), traits are **permanent**
- Clamps stats to prevent game-breaking values (work speed: 0.2x – 3.0x)
- Event log is **ephemeral only** (not saved)
- Chaos traits have **randomized modifiers** at runtime

## Important Files

- `Scripts/Core/TraitDefinitions.cs`: All trait definitions (20 traits across 5 categories)
- `Scripts/Core/TraitRegistry.cs`: Global registry of traits
- `Scripts/Core/BeaverPersonality.cs`: Per-beaver trait storage + mood state
- `Scripts/Core/MoodState.cs`: Mood enum and state machine
- `Scripts/Core/TraitAssigner.cs`: Assigns traits on beaver spawn
- `Scripts/Configuration/BeaverBehaviorConfigurator.cs`: Main DI configurator
- `Scripts/Configuration/BeaverBehaviorModStarter.cs`: Mod entry point
- `Data/Blueprints/BeaverPersonality.blueprint.json`: Trait pool definitions
- `Data/Localizations/enUS_BeaverBehaviorBreakdown.csv`: Trait names/descriptions
- `Scripts/BeaverBehaviorBreakdown.asmdef`: Assembly definition

## Testing

Tests are run through the timberborn-modding test infrastructure. For single test:
- Run via timberborn-modding test runner targeting `BeaverBehaviorBreakdown` project

## Extending the Mod

### Adding a Trait

1. Define in `Scripts/Core/TraitDefinitions.cs`:
```csharp
yield return new PersonalityTrait
{
    Id = "NewTraitId",
    DisplayNameLocKey = "BBB.Trait.NewTrait.Name",
    Category = TraitCategory.X,
    WorkSpeedModifier = 1.0f,
    // ... other modifiers
};
```

2. Add localization entry to `Data/Localizations/enUS_BeaverBehaviorBreakdown.csv`

3. Implement modifiers in `Scripts/BehaviorModifiers/BehaviorModifierService.cs`

### UI Customization

Edit `Scripts/UI/PersonalityPanelFragment.cs` to add new UI elements to the beaver panel.

## Related Projects

- [timberborn-modding](https://github.com/mechanistry/timberborn-modding): Core modding framework
- [Timberborn](https://www.timberborn.io/): Base game
